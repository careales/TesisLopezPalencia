from dolfin import *
from multiphenics import *
from helpers import *
import sympy2fenics as sf
import matplotlib.pyplot as plt
parameters["ghost_mode"] = "shared_facet"  # requireda para dS

parameters["form_compiler"]["representation"] = "uflacs"
parameters["form_compiler"]["cpp_optimize"] = True
parameters["form_compiler"]["quadrature_degree"] = 3


# Create mesh and define function space
# mesh = UnitSquareMesh(32, 32)

omega1 = 5; omega2 = 6; omega3= 7; borde = 1
mesh = Mesh("./malla_pepino.xml")
boundaries = MeshFunction("size_t", mesh, "./malla_pepino_facet_region.xml")
subdomains = MeshFunction("size_t", mesh, "./malla_pepino_physical_region.xml")
x = SpatialCoordinate(mesh); 
r = x[0]

plt.figure()
plot(mesh, linewidth=1.0)

plt.show()
#subdomains = MeshFunction("size_t", mesh, 2)
#subdomains.set_all(0)

n = FacetNormal(mesh); t = as_vector((-n[1], n[0]))
#hh.append(mesh.hmax())

    # ******* Creacion Subdominios, fronteras e interface ****** #

dx = Measure("dx", domain=mesh, subdomain_data=subdomains)
ds = Measure("ds", domain=mesh, subdomain_data=boundaries)
dS = Measure("dS", domain=mesh, subdomain_data=boundaries)

meshS = SubMesh(mesh, subdomains, omega1)
meshD = SubMesh(mesh, subdomains, omega2)
# Visualizacion
plt.figure()
plot(meshS, linewidth=1.0)
plt.show()
# Visualizacion
plt.figure()
plot(meshD, linewidth=1.0)
plt.show()

t = 0.0; dt = 2; tfinal = 500; 
inc = 0;   frequency = 10;
V = FunctionSpace(mesh, "CG",1)
P12  = FunctionSpace(mesh, "CG",1)

T = TrialFunction(V)
v = TestFunction(V)
    #                     T, 


T_D=Constant(60.0)
TD_D=Constant(60.0)  
Told = project(Constant(25.0),V)  



# Define given data
rho1 = Constant(1031.42)
rho2 = Constant(1031.42)
rho3 = Constant(1031.42)
Cp1 = Constant(3865.87)
Cp2 = Constant(3865.87)
Cp3 = Constant(3865.87)
kappa1 = Constant(0.6124)
kappa2 = Constant(0.6124)
kappa3 = Constant(0.6124)
fOm1 = Expression(("0.0"),degree=1)
fOm2 = Expression(("0.0"),degree=1)
hconv = Constant(643.6)
Tinf = Constant(80.0)
    # Formas bilineales #

a1 =  (1/dt)*rho1*Cp1*inner(T, v)*r* dx(5)+(1/dt)*rho2*Cp2*inner(T, v)*r* dx(6)+(1/dt)*rho3*Cp3*inner(T, v)*r* dx(7)+kappa1*inner(grad(T),grad(v))*r* dx(5)+kappa2*inner(grad(T),grad(v))*r* dx(6)+kappa3*inner(grad(T),grad(v))*r* dx(7)  + hconv*T*v*r*ds(borde) 

L =  (1/dt)*rho1*Cp1*inner(Told, v)*r*dx(5)+(1/dt)*rho2*Cp2*inner(Told,v)*r*dx(6)+(1/dt)*rho3*Cp3*inner(Told,v)*r*dx(7)+hconv*Tinf*v*r*ds(borde)

#c=plot(Told)
#print(type(c))
#plt.colorbar(c)
#plt.show()
#print(dir(c))
#plt.colorbar(c)

# Create VTK file for saving solution
vtkfile = File('carpeta_soluciones/solution.pvd')
#print("Temperatura en tiempo cero=%.3f" % Told(0.01,0.03))
while(t < tfinal):
    t += dt; print("t=%.3f" % t)
    T = Function(V)


    solve(a1 == L, T)
    print("Temperatura en cero=%.3f" % T(0.0,0.05))
    
    # Save to file and plot solution
    vtkfile << (T,t)
    plot(T)
    ufile_pvd = File("Temperatura.pvd")
    ufile_pvd << T

    assign(Told,T)
   
    
# ******** End of time loop **** #

# Save solution in VTK format



# Plot solution
#plt.figure()
#plot(T, title="Temperatura")

# Save solution in VTK format






# Display plots
plt.show()

# Plot solution
#plt.figure()
#plot(T, title="Temperatura")



# Display plots
plt.show()



c=plot(T)
print(type(c))
plt.colorbar(c)
plt.show()
print(dir(c))
plt.colorbar(c)

c=plot(T,title="Distibucion de Temperatura")
print(type(c))
plt.colorbar(c)
plt.show()
print(dir(c))
plt.colorbar(c)


#meshomega1 = SubMesh(mesh, subdomains, omega1)
#meshomega2 = SubMesh(mesh, subdomains, omega2)
# Visualizacion
# plt.figure()
# plot(mesh, linewidth=1.0)
# plt.show()

