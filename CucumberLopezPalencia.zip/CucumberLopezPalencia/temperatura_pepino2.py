from dolfin import *
from multiphenics import *
from helpers import *
import sympy2fenics as sf
import matplotlib.pyplot as plt
import numpy as np
parameters["ghost_mode"] = "shared_facet"  # requireda para dS

parameters["form_compiler"]["representation"] = "uflacs"
parameters["form_compiler"]["cpp_optimize"] = True
parameters["form_compiler"]["quadrature_degree"] = 3


# Create mesh and define function space
# mesh = UnitSquareMesh(32, 32)

omega1 = 5; omega2 = 6; borde = 1
mesh = Mesh("./malla_pepino2.xml")
boundaries = MeshFunction("size_t", mesh, "./malla_pepino2_facet_region.xml")
subdomains = MeshFunction("size_t", mesh, "./malla_pepino2_physical_region.xml")
x = SpatialCoordinate(mesh); 
r = x[0]

plt.figure()
plot(mesh, linewidth=1.0)

plt.show()
#subdomains = MeshFunction("size_t", mesh, 2)
#subdomains.set_all(0)

n = FacetNormal(mesh); t = as_vector((-n[1], n[0]))
#hh.append(mesh.hmax())

    # ******* Creacion Subdominios, fronteras e interface ****** #

dx = Measure("dx", domain=mesh, subdomain_data=subdomains)
ds = Measure("ds", domain=mesh, subdomain_data=boundaries)
dS = Measure("dS", domain=mesh, subdomain_data=boundaries)

meshS = SubMesh(mesh, subdomains, omega1)
meshD = SubMesh(mesh, subdomains, omega2)
# Visualizacion
plt.figure()
plot(meshS, linewidth=1.0)
plt.show()
# Visualizacion
plt.figure()
plot(meshD, linewidth=1.0)
plt.show()

t = 0.0; dt = 10; tfinal = 6000; 
inc = 0;   frequency = 10;
V = FunctionSpace(mesh, "CG",1)
P12  = FunctionSpace(mesh, "CG",1)

T = TrialFunction(V)
v = TestFunction(V)
    #                     T, 


T_D=Constant(60.0)
TD_D=Constant(60.0)  
Told = project(Constant(20.0),V)  
Ttemp100 = project(Constant(0.0),V)  
Ttemp500 = project(Constant(0.0),V) 
Ttemp1000 = project(Constant(0.0),V) 

# Define given data
rho1 = Constant(959.00)
rho2 = Constant(959.00)
Cp1 = Constant(4130.00)
Cp2 = Constant(4120.00)

kappa1 = Constant(0.6100)
kappa2 = Constant(0.5700)

fOm1 = Expression(("0.0"),degree=1)
fOm2 = Expression(("0.0"),degree=1)
hconv = Constant(1000.6)
Tinf = Constant(80.0)
    # Formas bilineales #

a1 =  (1/dt)*rho1*Cp1*inner(T, v)*r* dx(5)+(1/dt)*rho2*Cp2*inner(T, v)*r* dx(6)+kappa1*inner(grad(T),grad(v))*r* dx(5)+kappa2*inner(grad(T),grad(v))*r* dx(6) + hconv*T*v*r*ds(borde) 

L =  (1/dt)*rho1*Cp1*inner(Told, v)*r*dx(5)+(1/dt)*rho2*Cp2*inner(Told,v)*r*dx(6)+hconv*Tinf*v*r*ds(borde)

#c=plot(Told)
#print(type(c))
#plt.colorbar(c)
#plt.show()
#print(dir(c))
#plt.colorbar(c)

# Create VTK file for saving solution
vtkfile = File('carpeta_soluciones/solution.pvd')
salida_t=np.array([])
salida_T1=np.array([])
salida_T2=np.array([])
salida_T3=np.array([])
#print("Temperatura en tiempo cero=%.3f" % Told(0.00,0.10))
while(t < tfinal):
    t += dt; print("t=%.3f" % t)
    T = Function(V)


    solve(a1 == L, T)
    print("Temperatura en cero=%.3f" % T(0.0,0.05))
    salida_T1=np.append(salida_T1,T(0.000,0.100))
    salida_T2=np.append(salida_T2,T(0.010,0.100))
    salida_T3=np.append(salida_T3,T(0.01800,0.100))
    salida_t=np.append(salida_t,t)
    # Save to file and plot solution

    if t==100:
    	assign(Ttemp100,T)
    if t==500:
    	assign(Ttemp500,T)
    if t==1000:
        assign(Ttemp1000,T)

    	
    assign(Told,T)
   
    
# ******** End of time loop **** #
 # Save to file and plot solution
vtkfile << (Ttemp500)

ufile_pvd = File("Temperatura500.pvd")
ufile_pvd << Ttemp500


vtkfile << (Ttemp1000)

ufile_pvd = File("Temperatura100.pvd")
ufile_pvd << Ttemp1000
salida=np.array([salida_t, salida_T1, salida_T2, salida_T3])
salida1=np.array([salida_t, salida_T1])
plt.figure()
plt.plot(salida_t,salida_T1,label='Punto Centro')
plt.plot(salida_t,salida_T2,label='Punto Mesocarpio')
plt.plot(salida_t,salida_T3,label='Punto Superficie')
plt.legend()
plt.show()
print(salida)
#guardar salidas
np.savetxt('paratikz.out',salida1, delimiter=',')
np.savetxt('paratikz.out', salida1, fmt='%1.4e')   # use exponential notation
np.loadtxt('paratikz.out')
np.savetxt('myfileT1.dat', np.c_[salida_t,salida_T1])
np.savetxt('myfileT2.dat', np.c_[salida_t,salida_T2])
np.savetxt('myfileT3.dat', np.c_[salida_t,salida_T3])
# Save solution in VTK format



# Plot solution
#plt.figure()
#plot(T, title="Temperatura")

# Save solution in VTK format






# Display plots
plt.show()

c=plot(Ttemp100,title="Distibucion de Temperatura en 100")
#print(type(c))
plt.colorbar(c)
plt.show()
print(dir(c))
#plt.colorbar(c)


c=plot(Ttemp500,title="Distibucion de Temperatura 500")
print(type(c))
plt.colorbar(c)
plt.show()
print(dir(c))


c=plot(Ttemp1000,title="Distibucion de Temperatura 1000")
print(type(c))
plt.colorbar(c)
plt.show()
print(dir(c))



c=plot(T,title="Distibucion de Temperatura final")
print(type(c))
plt.colorbar(c)
plt.show()
print(dir(c))
#plt.colorbar(c)



